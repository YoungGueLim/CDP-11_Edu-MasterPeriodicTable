//
//  PublicAPITableViewCell.swift
//  ETSampleApp
//
//  Created by yongdamsh on 2016. 2. 14..
//  Copyright © 2016년 Encored Technologies, Inc. All rights reserved.
//

import UIKit

class PublicAPITableViewCell: UITableViewCell {

    // MARK: Properties
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    
}
