package com.encoredtech.devsample.service;

import com.encoredtech.devsample.vo.AuthInfoVo;

/**
 * Created by koansang on 2016. 2. 15..
 */
public class Define {
    /* Auth Info.*/
    public static final String CLIENT_ID = "S29hbnNhbmdAZW5jb3JlZHRlY2guY29tX0RldiBTYW1wbGUgQXBw";
    public static final String CLIENT_SECRET = "7c11740u5nd5fu5zb47620f1p56ek6so9xy3368";
    public static final String AUTH_DOMAIN = "https://enertalk-auth.encoredtech.com";
    public static final String HOME_DOMAIN = "https://api.encoredtech.com:8082/1.2";
    public static final String CARD_DOMAIN = "https://enertalk-card.encoredtech.com";
    public static String ACCESS_TOKEN = "";
    public static String UUID = "";
    public static AuthInfoVo AUTH_INFO = null;


}
