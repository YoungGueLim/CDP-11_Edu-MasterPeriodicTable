/* Directives for the app */
angular.module('app.directives', [])

.directive('blankDirective', [function(){

}]);

